using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class NuovoUtente : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {

		if (!IsPostBack)
		{
			//	----------------------------------------------------------------------------------------------------
			//	Carico i DropDownList per Societ� e Organization Unit
			//	----------------------------------------------------------------------------------------------------
			myParameter p;

			myParameters parSocieta = new myParameters();
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboSocieta.SelectedIndex == 0 && cboSocieta.Items.Count == 2) cboSocieta.SelectedIndex = 1;
			if (cboSocieta.Items.Count == 2)
			{ cboSocieta.SelectedIndex = 1; }
			else
			{ cboSocieta.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�; se non sono Admin solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			myParameters parOrgUnit = new myParameters();
			if ((string)Session["flSocieta"] == "1" && cboSocieta.SelectedIndex == 0)
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			//{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString()); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono Admin posso gestire solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flOrgUnit"] == "1")
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, ""); }
			else
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)Session["dsOrgUnit"]); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//
			Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola Organization Unit, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			//if (cboOrgUnit.SelectedIndex == 0 && cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
			if (cboOrgUnit.Items.Count == 2)
			{ cboOrgUnit.SelectedIndex = 1; }
			else
			{ cboOrgUnit.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Controllo se sono abilitato a gestire pi� societ� e pi� OrgUnit
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{
				Panel_Societa.Visible = true;
				Panel_OrgUnit.Visible = true;
				Panel_Inizio.Visible = true;
			}
			else
			{
				cboSocieta.SelectedValue = (string)Session["dsCodSoc"];
				lblSocieta.Text = cboSocieta.SelectedItem.ToString();
				Visua_Societa.Visible = true;
				//	----------------------------------------------------------------------------------------------------
				if ((string)Session["flOrgUnit"] == "1")
				{
					Panel_OrgUnit.Visible = true;
				}
				else
				{
					lblOrgUnit.Text = (string)Session["dsOrgUnit"];
					Visua_OrgUnit.Visible = true;
				}
				Panel_Inizio.Visible = false;
				BindData();
			}
		}
	}

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		Panel_Inizio.Visible = false;
		Panel_None.Visible = false;
		Panel_Trovati.Visible = false;
		Panel_Inizio.Visible = true;
		dgUtenti.Visible = false;
		if (cboSocieta.SelectedIndex > 0 && (cboOrgUnit.SelectedIndex > 0 || !string.IsNullOrEmpty(txtRicerca.Text)))
		{
			Panel_Inizio.Visible = false;
			BindData();
		}
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella BOL_TB_UTENTI da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		DataSet ds;
		ds = GetUtenti(cboSocieta.SelectedValue.ToString(), cboOrgUnit.SelectedValue.ToString(), txtRicerca.Text.ToString());
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgUtenti.DataSource = ds;
			dgUtenti.DataBind();
			dgUtenti.Visible = true;
			Panel_None.Visible = false;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
		}
		else
		{
			Panel_None.Visible = true;
			dgUtenti.Visible = false;
			Panel_Trovati.Visible = false;
		}
		return;
	}

	public static DataSet GetUtenti(string societa, string orgunit, string ricerca)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(societa))
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, (string)societa);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(orgunit))
		{
			p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)orgunit);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		if (!string.IsNullOrEmpty(ricerca) && ricerca.TrimEnd() != "")
		{
			p = new myParameter("@Ricerca", SqlDbType.VarChar, 50, (string)ricerca);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiUtentiNew", collP);
		return ds;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco utenti
	//	----------------------------------------------------------------------------------------------------------------------------------------
	public void dgUtenti_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
		dgUtenti.CurrentPageIndex = e.NewPageIndex;
	}

	protected void btnCerca_Click(object sender, ImageClickEventArgs e)
	{ }

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgUtenti.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgUtenti.CurrentPageIndex = 0;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizzazione dettaglio utente
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void dgUtenti_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgUtenti.SelectedIndex = e.Item.ItemIndex;
				Panel_Utente.Visible = true;
				break;

			case "Collapse":
				dgUtenti.SelectedIndex = -1;
				Panel_Utente.Visible = false;
				break;
		}
	}

	protected void dgUtenti_Dettaglio(object source, DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;

			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli utente";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli utente selezionato
				//	----------------------------------------------------------------------------------------------------
				Utente VisUtente = new Utente((dgUtenti.DataKeys[e.Item.ItemIndex]).ToString());
				ViewState["Utente"] = VisUtente;
				utGid.Text = VisUtente.ceGid;
				utNome.Text = VisUtente.dsCognome + " " + VisUtente.dsNome;
				utSocieta.Text = VisUtente.dsCodSoc + " - " + VisUtente.deSocieta;
				utOrgUnit.Text = VisUtente.dsOrgUnit;
				utLocalita.Text = VisUtente.dsLocalita;
				utTipoUtente.Text = VisUtente.dsTipoUtente;
				ckbEmetti.Checked = VisUtente.flEmetti;
				ckbRiepilogo.Checked = VisUtente.flRiepilogo;
				ckbOrgUnit.Checked = VisUtente.flOrgUnit;
				ckbAdmin.Checked = VisUtente.flAdmin;
				ckbSocieta.Checked = VisUtente.flSocieta;
				Panel_Funzioni.Visible = true;
				if ((string)Session["flSuper"] == "1") Panel_Admin.Visible = true;
				Panel_Comandi.Visible = true;
			}
		}
	}


	//	----------------------------------------------------------------------------------------------------
	//	Inserimento abilitazione nuovo utente
	//	----------------------------------------------------------------------------------------------------
	protected void cmdInserisci_OnClick(object sender, EventArgs e)
	{
		Utente insUtente;
		insUtente = (Utente)ViewState["Utente"];
		insUtente.flAdmin = ckbAdmin.Checked;
		insUtente.flEmetti = ckbEmetti.Checked;
		insUtente.flRiepilogo = ckbRiepilogo.Checked;
		insUtente.flSocieta = ckbSocieta.Checked;
		insUtente.flOrgUnit = ckbOrgUnit.Checked;
		insUtente.Inserisci_Utente();
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}

	protected void cmdAnnulla_OnClick(object sender, EventArgs e)
	{
		dgUtenti.SelectedIndex = -1;
		Panel_Utente.Visible = false;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		myParameters parOrgUnit = new myParameters();
		myParameter p;
		p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, "");
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
		//	----------------------------------------------------------------------------------------------------
		//	Se risulta una sola Organization Unit, la si seleziona
		//	----------------------------------------------------------------------------------------------------
		if (cboOrgUnit.SelectedIndex == 0 && cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
		dgUtenti.CurrentPageIndex = 0;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Organization Unit
	//	----------------------------------------------------------------------------------------------------
	protected void cboOrgUnit_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgUtenti.CurrentPageIndex = 0;
	}


}
