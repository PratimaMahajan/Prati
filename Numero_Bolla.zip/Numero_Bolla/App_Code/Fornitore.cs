using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Fornitore
/// </summary>
/// 


[Serializable()]
public class Fornitore
{
	private string _ceFornitore;
	private string _deFornitore;
	private string _deRagSociale;
	private string _nmEsterni;

	public string ceFornitore
	{
		get { return _ceFornitore; }
	}

	public string deFornitore
	{
		get { return _deFornitore; }
	}
	public string deRagSociale
	{
		get { return _deRagSociale; }
	}

	public string nmEsterni
	{
		get { return _nmEsterni; }
	}

	public Fornitore()
	{
		_ceFornitore = "";
		_deFornitore = "";
		_deRagSociale = "";
	}

	//	----------------------------------------------------------------------------------------------------
	//	Estrazione dati Fornitore
	//	----------------------------------------------------------------------------------------------------
	public Fornitore(string fornitore)
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@Fornitore", SqlDbType.Int, 8, Convert.ToDouble(fornitore));
		collP.Add(p.CreateSQLParameter());
		SqlDataReader dr = DBHelper.GetSPReader("BOL_sp_GetFornitore", collP);
		//
		if ((dr != null) && dr.Read())
		{
			_ceFornitore = dr["ceFornitore"].ToString();
			_deFornitore = dr["deFornitore"].ToString();
			_deRagSociale = dr["deRagSociale"].ToString();
			_nmEsterni = dr["nmEsterni"].ToString();
		}
		else
		{
			_ceFornitore = "";
		}
		dr.Close();
	}

	//	----------------------------------------------------------------------------------------------------
	//	Inserimento nuovo Fornitore
	//	----------------------------------------------------------------------------------------------------
	public void Insert_Fornitore(string deFornitore, string deRagSociale)
	{
		myParameters collP = new myParameters();
		myParameter p;
		//
		p = new myParameter("@deFornitore", SqlDbType.VarChar, 50, deFornitore);
		collP.Add(p.CreateSQLParameter());
		p = new myParameter("@deRagSociale", SqlDbType.VarChar, 50, deRagSociale);
		collP.Add(p.CreateSQLParameter());
		DBHelper.ExecuteNonQuery("BOL_sp_InsertFornitore", collP);
	}

}
